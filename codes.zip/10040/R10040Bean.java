package jp.co.future.fjy.cl.beans.ord;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import jp.co.future.fjy.cl.beans.BizBaseBean;
import jp.co.future.project.palette.cl.annotation.SearchCondition;
import jp.co.future.project.palette.cl.viewmodel.codename.CodeNameModel;
import jp.co.future.project.palette.cl.viewmodel.select.SelectModel;

/**
 * 10040；セール発注CSVダウンロード
 *
 * @author 侯慶好
 */
@Component
@Scope("view")
public class R10040Bean extends BizBaseBean {

	/** セール名 */
	@SearchCondition
	private SelectModel saleNm = new SelectModel();
	/** 業務 */
	@SearchCondition
	private String bizCd;
	/** 地区 */
	@SearchCondition
	private String districtTyp;
	/** 地区サブ */
	@SearchCondition
	private SelectModel districtSubNm = new SelectModel();
	/** 地区部 */
	@SearchCondition
	private SelectModel districtDepartNm = new SelectModel();
	/** SV */
	@SearchCondition
	private SelectModel svCd = new SelectModel();
	/** 店舗 */
	@SearchCondition
	private final CodeNameModel store = new CodeNameModel();
	/** 部門 */
	@SearchCondition
	private final SelectModel typValNm = new SelectModel();
	/** チャネル */
	@SearchCondition
	private String channel;

	/**
	 * セール名を取得します
	 *
	 * @return saleNm セール名
	 */
	public SelectModel getSaleNm() {
		return this.saleNm;
	}

	/**
	 * セール名をセットします
	 *
	 * @param saleNm セール名
	 */
	public void setSaleNm(final SelectModel saleNm) {
		this.saleNm = saleNm;
	}

	/**
	 * 業務を取得します
	 *
	 * @return bizCd 業務
	 */
	public String getBizCd() {
		return this.bizCd;
	}

	/**
	 * 業務をセットします
	 *
	 * @param bizCd 業務
	 */
	public void setBizCd(final String bizCd) {
		this.bizCd = bizCd;
	}

	/**
	 * 地区を取得します
	 *
	 * @return districtTyp 地区
	 */
	public String getDistrictTyp() {
		return this.districtTyp;
	}

	/**
	 * 地区をセットします
	 *
	 * @param districtTyp 地区
	 */
	public void setDistrictTyp(final String districtTyp) {
		this.districtTyp = districtTyp;
	}

	/**
	 * 地区サブを取得します
	 *
	 * @return districtSubNm 地区サブ
	 */
	public SelectModel getDistrictSubNm() {
		return this.districtSubNm;
	}

	/**
	 * 地区サブをセットします
	 *
	 * @param districtSubNm 地区サブ
	 */
	public void setDistrictSubNm(final SelectModel districtSubNm) {
		this.districtSubNm = districtSubNm;
	}

	/**
	 * 地区部を取得します
	 *
	 * @return districtDepartNm 地区部
	 */
	public SelectModel getDistrictDepartNm() {
		return this.districtDepartNm;
	}

	/**
	 * 地区部をセットします
	 *
	 * @param districtDepartNm 地区部
	 */
	public void setDistrictDepartNm(final SelectModel districtDepartNm) {
		this.districtDepartNm = districtDepartNm;
	}

	/**
	 * SVを取得します
	 *
	 * @return svCd SV
	 */
	public SelectModel getSvCd() {
		return this.svCd;
	}

	/**
	 * SVをセットします
	 *
	 * @param svCd SV
	 */
	public void setSvCd(final SelectModel svCd) {
		this.svCd = svCd;
	}

	/**
	 * チャネルを取得します
	 *
	 * @return channel チャネル
	 */
	public String getChannel() {
		return this.channel;
	}

	/**
	 * チャネルをセットします
	 *
	 * @param channel チャネル
	 */
	public void setChannel(final String channel) {
		this.channel = channel;
	}

	/**
	 * 店舗を取得します
	 *
	 * @return store 店舗
	 */
	public CodeNameModel getStore() {
		return this.store;
	}

	/**
	 * 部門を取得します
	 *
	 * @return typValNm 部門
	 */
	public SelectModel getTypValNm() {
		return this.typValNm;
	}
}
