package jp.co.future.fjy.bl.controller.ord;

import org.springframework.stereotype.Controller;

import jp.co.future.common.appcore.utils.CollectionUtils;
import jp.co.future.common.appcore.utils.DateUtils;
import jp.co.future.common.appcore.utils.StringUtils;
import jp.co.future.common.palette.commands.SqlQueryCommand;
import jp.co.future.common.palette.commands.exceptions.CommandLogicException;
import jp.co.future.fjy.bl.controller.biz.BizBaseWebController;
import jp.co.future.fjy.common.parameter.ord.R10040Parameter;
import jp.co.future.fjy.common.parameter.ord.R10040ReplyParameter;
import jp.co.future.fjy.common.parameter.ord.R10040RequestParameter;

/**
 * 10040；セール発注CSVダウンロード
 *
 * @author 侯慶好
 */
@Controller
public class R10040Controller extends BizBaseWebController<R10040Parameter> {

	/**
	 * 初期処理イベントのBL
	 *
	 * @see jp.co.future.project.palette.bl.controller.BaseController#doInitialize()
	 */
	@Override
	protected void doInitialize() throws CommandLogicException {
		//検索
		this.executeSearch();
	}

	/**
	 * 検索処理を行う
	 *
	 * @throws CommandLogicException
	 */
	protected void executeSearch() throws CommandLogicException {

		//Actionで設定したRequestParameterを取得
		//R10040RequestParameter request = this.getParameter().getRequest();

		//画面.セール名のプルダウンリストを生成する
		SqlQueryCommand command1 = this.createSqlQueryCommand("ord/R10040_801_SEL_M_SELL");
		//SQLの実行
		this.executeCommand(command1);
		// 検索結果をReplyへセット
		this.getParameter().getReply().setExecCommand1(command1);

		//画面.地区サブのプルダウンリストを生成する
		SqlQueryCommand command2 = this.createSqlQueryCommand("ord/R10040_802_SEL_M_REGI_DATA_STORE");
		//SQLの実行
		this.executeCommand(command2);
		// 検索結果をReplyへセット
		this.getParameter().getReply().setExecCommand2(command2);

		//画面.地区部のプルダウンリストを生成する
		SqlQueryCommand command3 = this.createSqlQueryCommand("ord/R10040_803_SEL_M_REGI_DATA_STORE");
		//SQLの実行
		this.executeCommand(command3);
		// 検索結果をReplyへセット
		this.getParameter().getReply().setExecCommand3(command3);

		//画面.SVのプルダウンリストを生成する。
		SqlQueryCommand command4 = this.createSqlQueryCommand("ord/R10040_804_SEL_M_REGI_DATA_STORE");
		//SQLの実行
		this.executeCommand(command4);
		// 検索結果をReplyへセット
		this.getParameter().getReply().setExecCommand4(command4);

		//画面.部門のプルダウンリストを生成する。
		SqlQueryCommand command5 = this.createSqlQueryCommand("ord/R10040_805_SEL_M_STORE");
		//SQLの実行
		this.executeCommand(command5);
		// 検索結果をReplyへセット
		this.getParameter().getReply().setExecCommand5(command5);
	}

	/**
	 * 店舗ボタン押下時イベント処理。
	 *
	 * @see jp.co.future.fjy.bl.controller.biz.BizBaseWebController#doExecute()
	 */
	@Override
	protected void doPopupCallback() throws CommandLogicException {
		doExecute();
	}

	@Override
	protected void doExecute() throws CommandLogicException {
		// リクエストパラメータをローカル変数に格納
		R10040RequestParameter request = getParameter().getRequest();
		R10040ReplyParameter reply = getReply();
		SqlQueryCommand command6 = this.createSqlQueryCommand("ord/R10040_806_SEL_M_STORE");
		// 戻り値.店舗コード
		command6.addParam("storeCd", request.getStoreCd());
		//SQLの実行
		this.executeCommand(command6);
		// 検索結果をReplyへセット
		reply.setDepartmentCd(command6.getResult().get(0).get("departmentCd"));
	}

	/**
	 * 店舗コード値変更
	 *
	 * @see jp.co.future.skyretail.std.bl.controller.biz.BizBaseWebController#doInputCompletion()
	 */
	@Override
	protected void doInputCompletion() throws CommandLogicException {
		// リクエストパラメータをローカル変数に格納
		R10040RequestParameter request = getParameter().getRequest();
		R10040ReplyParameter reply = getReply();
		if (StringUtils.isNotEmpty(request.getStoreCd())) {
			SqlQueryCommand command = createSqlQueryCommand("mst/R10124_101_SEL_M_ORG");
			// 基準日
			command.addParam("referenceDate", DateUtils.parse(request.getBizYmd()));
			// 店舗コード
			command.addParam("storeCd", request.getStoreCd());
			// SQLの実行
			executeCommand(command);
			//検索結果が存在する場合、取得した店舗名を画面.店舗に設定する。
			if (CollectionUtils.isNotEmpty(command.getResult())) {
				// 検索結果をReplyにセット
				reply.setStoreNm(command.getResult().get(0).get("storeNm"));
				//入力された店舗コードに紐づく部門情報を取得する。
				SqlQueryCommand command7 = this.createSqlQueryCommand("ord/R10040_807_SEL_M_STORE");
				//戻り値.店舗コード
				command7.addParam("storeCd", request.getStoreCd());
				//SQLの実行
				this.executeCommand(command7);
				// 検索結果をReplyへセット
				reply.setDepartmentCd(command7.getResult().get(0).get("departmentCd"));
			}
		}
	}

	/**
	 * CSVボタン押下
	 *
	 * @see jp.co.future.skyretail.std.bl.controller.biz.BizBaseWebController#doExport()
	 */
	@Override
	protected void doExport() throws CommandLogicException {
		R10040RequestParameter request = getParameter().getRequest();
		//R10040ReplyParameter reply = getReply();
		// パラメータ設定して検索
		SqlQueryCommand command8 = createTableListSqlQueryCommand("por/R10263_801_SEL_T_SELL_PUR_ORDER_REQ");
		//セール区分
		command8.addParam("saleTyp", request.getSaleTyp());
		//セール表示開始日
		command8.addParam("saleDispBegnDate", request.getSaleDispBegnDate());
		//セール表示終了日
		command8.addParam("saleDispFinishDate", request.getSaleDispFinishDate());
		//画面.業務コード区分
		command8.addParam("bizCd", request.getBizCd());
		//画面.地区区分値
		command8.addParam("districtTyp", request.getDistrictTyp());
		//画面.地区サブ名
		command8.addParam("districtSubNm", request.getDistrictSubNm());
		//画面.地区部名
		command8.addParam("districtDepartNm", request.getDistrictDepartNm());
		//画面.SVコード
		command8.addParam("svCd", request.getSvCd());
		//画面.店舗コード
		command8.addParam("storeCd", request.getStoreCd());
		//画面.部門コード
		command8.addParam("departmentCd", request.getDepartmentCd());
		//画面.チャネル区分値(出荷先区分値)
		command8.addParam("shipToTyp", request.getChannel());
		//SQLの実行
		this.executeCommand(command8);
	}
}