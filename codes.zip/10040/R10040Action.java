package jp.co.future.fjy.cl.actions.ord;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.faces.event.ActionEvent;
import javax.faces.event.AjaxBehaviorEvent;

import org.primefaces.event.SelectEvent;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import jp.co.future.common.appcore.utils.StringUtils;
import jp.co.future.common.palette.commands.SqlQueryCommand;
import jp.co.future.fjy.cl.actions.BizBaseAction;
import jp.co.future.fjy.cl.beans.ord.R10040Bean;
import jp.co.future.fjy.common.parameter.biz.BizBaseWebParameter;
import jp.co.future.fjy.common.parameter.biz.BizBaseWebReplyParameter;
import jp.co.future.fjy.common.parameter.biz.BizBaseWebRequestParameter;
import jp.co.future.fjy.common.parameter.ord.R10040Parameter;
import jp.co.future.fjy.common.parameter.ord.R10040ReplyParameter;
import jp.co.future.fjy.common.parameter.ord.R10040RequestParameter;
import jp.co.future.project.palette.cl.utils.ViewModelCopyUtils;
import jp.co.future.project.palette.cl.viewmodel.table.TableModel;

/**
 * 10040:セール発注CSVダウンロード / Actionクラス
 *
 * @author Future 侯慶好
 */
@Controller
@Scope("request")
public class R10040Action extends BizBaseAction<R10040Bean> {

	/** タイトル */
	private static final String TITLE = "10040:セール発注CSVダウンロード";

	/**
	 * タイトル
	 */
	@Override
	public String getTitle() {
		return TITLE;
	}

	/**
	 * 初期表示
	 */
	@Override
	protected void doInitialize() {

		// 検索条件エリア・検索ボタンの非表示
		setSearchBtnRendered(false);
		// 帳票出力ボタン
		this.setPrintBtnRendered(true);
		// 検索実行
		executeSearch();
		// 検索済状態に移行し、検索結果エリアを明示的に表示とする。
		this.changeStateToEditContents();
		setContentsAreaRendered(false);
	}

	/**
	 * プルダウンリストを生成する。
	 */
	protected void executeSearch() {
		//パラメータクラス生成
		R10040Parameter parameter = createParameter(R10040Parameter.class);
		R10040RequestParameter request = parameter.getRequest();

		// Bean > Requestパラメータへセット
		ViewModelCopyUtils.copyBeanToRequest(getBean(), request);

		// BL実行
		executeBlController(parameter);

		R10040ReplyParameter reply = parameter.getReply();
		// セール名
		getBean().getSaleNm().setItems(reply.getExecCommand1().getResult());
		// 地区サブ
		getBean().getDistrictSubNm().setItems(reply.getExecCommand2().getResult());
		// 地区部
		getBean().getDistrictDepartNm().setItems(reply.getExecCommand3().getResult());
		// SV
		getBean().getSvCd().setItems(reply.getExecCommand4().getResult());
		// 部門
		getBean().getDepartmentCd().setItems(reply.getExecCommand5().getResult());
	}

	/**
	 * 店舗ボタン押下時イベント処理。
	 */
	protected void doExecute() {
		// パラメータクラス生成
		R10040Parameter parameter = createParameter(R10040Parameter.class);
		R10040RequestParameter request = parameter.getRequest();
		// Bean > Requestパラメータへセット
		ViewModelCopyUtils.copyBeanToRequest(getBean(), request);
		// BL実行
		executeBlController(parameter);
		// 部門
		getBean().getDepartmentCd().setSelectedValue(parameter.getReply().getDepartmentCd());
	}

	/**
	 * ポップアップ呼び出し
	 *
	 * @param actionEvent イベントオブジェクト
	 * @see jp.co.future.skyretail.std.cl.actions.BizBaseAction#doShowDialog(javax.faces.event.ActionEvent)
	 */
	@Override
	protected void doShowDialog(final ActionEvent event, final Map<String, List<String>> params) {
		// ポップアップにコンポーネント外のパラメータを渡す
		params.put("referenceDate", Arrays.asList(this.getBizYmd()));
		params.put("storeCd", Arrays.asList(getBean().getStore().getCd()));

	}

	@Override
	protected void doPopupCallback(final SelectEvent event, final String targetCname, final boolean isTableColumn) {
		if ("store".equals(targetCname)) {
			doExecute();
		}
	}

	/**
	 * 店舗値変更時イベント処理。
	 */
	@Override
	protected void doInputCompletion(final AjaxBehaviorEvent ajaxBehaviorEvent, final String targetCname,
			final boolean isTableColumn) {
		if (StringUtils.equals(targetCname, "storeCd")
				&& StringUtils.isNotEmpty(getBean().getStore().getCd())) {
			// パラメータクラス生成
			R10040Parameter parameter = createParameter(R10040Parameter.class);
			R10040RequestParameter request = parameter.getRequest();
			// コードを設定
			request.setStoreCd(getBean().getStore().getCd());
			// BL実行
			executeBlController(parameter);
			// 名称を保持
			getBean().getStore().setNm(parameter.getReply().getStoreNm());
			getBean().getDepartmentCd().setSelectedValue(parameter.getReply().getDepartmentCd());
		}
	}

	/**
	 * CSVボタン押下
	 */
	@Override
	protected void doExport(final ActionEvent actionEvent) {
		//		//パラメータクラス生成
		//		R10040Parameter parameter = createParameter(R10040Parameter.class);
		//		R10040RequestParameter request = parameter.getRequest();
		//
		//		// Bean > Requestパラメータへセット
		//		ViewModelCopyUtils.copyBeanToRequest(getBean(), request);
		//
		//		// BL実行
		//		executeBlController(parameter);

		BizBaseWebParameter parameter = createParameter(getParameterType());
		BizBaseWebRequestParameter request = parameter.getRequest();

		// Bean ＞ Requestパラメータへセット
		ViewModelCopyUtils.copyBeanToRequest(getBean(), request);

		TableModel tableModel = findExportTableModel(getBean());
		SqlQueryCommand exportQueryCommand = tableModel.getDataQueryCommand();

		// テーブルのカラム情報を取得してリクエストに詰める
		request.setExportColumns(getExportColumns(actionEvent));

		request.setExportTargetQueryCommand(exportQueryCommand);

		// BL実行
		executeBlController(parameter);

		BizBaseWebReplyParameter reply = parameter.getReply();

		//画面でダウンロード要求を実行
		writeStreamExportFile(reply.getExportFileName());
	}

}