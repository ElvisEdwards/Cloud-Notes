/*BEGIN*/
/*
 * 処理概要：
 * 入力された店舗コードに紐づく部門情報を取得する。
 *
 */
/*END*/
select /* _SQL_IDENTIFIER_ */
	msre.department_cd	as	department_cd	-- 部門コード
,	mtvl.typ_val_nm		as	typ_val_nm		-- 部門名称
from
	m_store	msre	-- 店舗マスタ
inner join
	m_typ_val	mtvl	-- 区分値マスタ
on
	mtvl.typ_catg_no	=	/*#CLS_DEPT_TYP*/'1131'	-- 区分値マスタ.区分種別番号 = [区分種別.部門区分]
and	mtvl.typ_val_no		=	msre.department_cd	-- 区分値マスタ.区分値番号 = 店舗マスタ.■部門コード
where
	msre.del_flg							=		/*#CLS_FLAG_OFF*/'00'				-- 店舗マスタ.削除フラグ
and	msre.store_cd							=		/*storeCd*/'1234'					-- 店舗マスタ.■店舗コード = 戻り値.店舗コード
and	cast(/*shoriYmd*/'20180101'	as	date)	between	msre.start_date	and	msre.end_date	-- 業務日付 between 店舗マスタ.適用開始日 and 店舗マスタ.適用終了日
order by
	msre.department_cd	-- 店舗マスタ.部門コード
