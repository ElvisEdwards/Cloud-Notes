/*BEGIN*/
/*
 * 処理概要：
 * レジデータ店舗マスタからSVコード、SV名、の一覧を取得する。
 *
 */
/*END*/
select /* _SQL_IDENTIFIER_ */
	mrds.sv_cd		as	value	-- レジデータ店舗マスタ.SVコード
,	max(mrds.sv_nm)	as	label	-- レジデータ店舗マスタ.SV名
from
	m_regi_data_store	mrds	-- レジデータ店舗マスタ
where
	mrds.del_flg							=		/*#CLS_FLAG_OFF*/'00'				-- レジデータ店舗マスタ.削除フラグ
and	cast(/*shoriYmd*/'20170101'	as	date)	between	mrds.start_date	and	mrds.end_date	-- 業務日付 BETWEEN レジデータ店舗マスタ.適用開始日 AND レジデータ店舗マスタ.適用終了日
group by
	mrds.sv_cd	-- レジデータ店舗マスタ.SVコード
order by
	mrds.sv_cd	-- レジデータ店舗マスタ.SVコード
