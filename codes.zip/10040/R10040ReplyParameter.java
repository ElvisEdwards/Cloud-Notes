package jp.co.future.fjy.common.parameter.ord;

import org.msgpack.annotation.MessagePackMessage;

import jp.co.future.common.palette.commands.SqlQueryCommand;
import jp.co.future.fjy.common.parameter.biz.BizBaseWebReplyParameter;

/**
 * 10040；セール発注CSVダウンロード
 *
 * @author Future 侯慶好
 */
@MessagePackMessage
public class R10040ReplyParameter extends BizBaseWebReplyParameter {

	/** 店舗コード */
	public String storeCd;
	/** 店舗名 */
	public String storeNm;
	/** セール名 */
	public String saleNm;
	/** 地区サブ名 */
	public String districtSubNm;
	/** 地区部 */
	public String districtDepartNm;
	/** SV */
	public String svCd;
	/** 部門 */
	public String departmentCd;
	/** 検索結果1 */
	public SqlQueryCommand execCommand1;
	/** 検索結果2 */
	public SqlQueryCommand execCommand2;
	/** 検索結果3 */
	public SqlQueryCommand execCommand3;
	/** 検索結果4 */
	public SqlQueryCommand execCommand4;
	/** 検索結果5 */
	public SqlQueryCommand execCommand5;
	/** 検索結果6 */
	public SqlQueryCommand execCommand6;
	/** 検索結果7 */
	public SqlQueryCommand execCommand7;

	/**
	 * 店舗コードを取得します
	 *
	 * @return storeCd 店舗コード
	 */
	public String getStoreCd() {
		return this.storeCd;
	}

	/**
	 * 店舗コードをセットします
	 *
	 * @param storeCd 店舗コード
	 */
	public void setStoreCd(final String storeCd) {
		this.storeCd = storeCd;
	}

	/**
	 * 店舗名を取得します
	 *
	 * @return storeNm 店舗名
	 */
	public String getStoreNm() {
		return this.storeNm;
	}

	/**
	 * 店舗名をセットします
	 *
	 * @param storeNm 店舗名
	 */
	public void setStoreNm(final String storeNm) {
		this.storeNm = storeNm;
	}

	/**
	 * セール名を取得します
	 *
	 * @return saleNm セール名
	 */
	public String getSaleNm() {
		return this.saleNm;
	}

	/**
	 * セール名をセットします
	 *
	 * @param saleNm セール名
	 */
	public void setSaleNm(final String saleNm) {
		this.saleNm = saleNm;
	}

	/**
	 * 地区サブ名を取得します
	 *
	 * @return districtSubNm 地区サブ名
	 */
	public String getDistrictSubNm() {
		return this.districtSubNm;
	}

	/**
	 * 地区サブ名をセットします
	 *
	 * @param districtSubNm 地区サブ名
	 */
	public void setDistrictSubNm(final String districtSubNm) {
		this.districtSubNm = districtSubNm;
	}

	/**
	 * 地区部を取得します
	 *
	 * @return districtDepartNm 地区部
	 */
	public String getDistrictDepartNm() {
		return this.districtDepartNm;
	}

	/**
	 * 地区部をセットします
	 *
	 * @param districtDepartNm 地区部
	 */
	public void setDistrictDepartNm(final String districtDepartNm) {
		this.districtDepartNm = districtDepartNm;
	}

	/**
	 * SVを取得します
	 *
	 * @return svCd SV
	 */
	public String getSvCd() {
		return this.svCd;
	}

	/**
	 * SVをセットします
	 *
	 * @param svCd SV
	 */
	public void setSvCd(final String svCd) {
		this.svCd = svCd;
	}

	/**
	 * 部門を取得します
	 *
	 * @return departmentCd 部門
	 */
	public String getDepartmentCd() {
		return this.departmentCd;
	}

	/**
	 * 部門をセットします
	 *
	 * @param departmentCd 部門
	 */
	public void setDepartmentCd(final String departmentCd) {
		this.departmentCd = departmentCd;
	}

	/**
	 * 検索結果1を取得します
	 *
	 * @return execCommand1 検索結果1
	 */
	public SqlQueryCommand getExecCommand1() {
		return this.execCommand1;
	}

	/**
	 * 検索結果1をセットします
	 *
	 * @param execCommand1 検索結果1
	 */
	public void setExecCommand1(final SqlQueryCommand execCommand1) {
		this.execCommand1 = execCommand1;
	}

	/**
	 * 検索結果2を取得します
	 *
	 * @return execCommand2 検索結果2
	 */
	public SqlQueryCommand getExecCommand2() {
		return this.execCommand2;
	}

	/**
	 * 検索結果2をセットします
	 *
	 * @param execCommand2 検索結果2
	 */
	public void setExecCommand2(final SqlQueryCommand execCommand2) {
		this.execCommand2 = execCommand2;
	}

	/**
	 * 検索結果3を取得します
	 *
	 * @return execCommand3 検索結果3
	 */
	public SqlQueryCommand getExecCommand3() {
		return this.execCommand3;
	}

	/**
	 * 検索結果3をセットします
	 *
	 * @param execCommand3 検索結果3
	 */
	public void setExecCommand3(final SqlQueryCommand execCommand3) {
		this.execCommand3 = execCommand3;
	}

	/**
	 * 検索結果4を取得します
	 *
	 * @return execCommand4 検索結果4
	 */
	public SqlQueryCommand getExecCommand4() {
		return this.execCommand4;
	}

	/**
	 * 検索結果4をセットします
	 *
	 * @param execCommand4 検索結果4
	 */
	public void setExecCommand4(final SqlQueryCommand execCommand4) {
		this.execCommand4 = execCommand4;
	}

	/**
	 * 検索結果5を取得します
	 *
	 * @return execCommand5 検索結果5
	 */
	public SqlQueryCommand getExecCommand5() {
		return this.execCommand5;
	}

	/**
	 * 検索結果5をセットします
	 *
	 * @param execCommand5 検索結果5
	 */
	public void setExecCommand5(final SqlQueryCommand execCommand5) {
		this.execCommand5 = execCommand5;
	}

	/**
	 * 検索結果6を取得します
	 *
	 * @return execCommand6 検索結果6
	 */
	public SqlQueryCommand getExecCommand6() {
		return this.execCommand6;
	}

	/**
	 * 検索結果6をセットします
	 *
	 * @param execCommand6 検索結果6
	 */
	public void setExecCommand6(final SqlQueryCommand execCommand6) {
		this.execCommand6 = execCommand6;
	}

	/**
	 * 検索結果7を取得します
	 *
	 * @return execCommand7 検索結果7
	 */
	public SqlQueryCommand getExecCommand7() {
		return this.execCommand7;
	}

	/**
	 * 検索結果7をセットします
	 *
	 * @param execCommand7 検索結果7
	 */
	public void setExecCommand7(final SqlQueryCommand execCommand7) {
		this.execCommand7 = execCommand7;
	}
}