package jp.co.future.fjy.common.parameter.ord;

import org.msgpack.annotation.MessagePackMessage;

import jp.co.future.common.palette.rtfa.parameter.PaletteBaseReplyParameter;
import jp.co.future.common.palette.rtfa.parameter.PaletteBaseRequestParameter;
import jp.co.future.fjy.common.parameter.biz.BizBaseWebParameter;

/**
 * 10040:セール発注CSVダウンロード
 *
 * @author Future 侯慶好
 */
@MessagePackMessage
public class R10040Parameter extends BizBaseWebParameter {
	/**
	 * リクエスト情報。
	 */
	public R10040RequestParameter request = null;

	/**
	 * リプライ情報。
	 */
	public R10040ReplyParameter reply = null;

	// ----------------- アクセサ ---------------------------
	/**
	 * リクエスト情報を返します。
	 *
	 * @return リクエスト情報
	 * @see jp.co.future.common.palette.rtfa.parameter.PaletteBaseParameter#getRequest()
	 */
	@SuppressWarnings("unchecked")
	@Override
	public R10040RequestParameter getRequest() {
		return this.request;
	}

	/**
	 * リクエスト情報をセットします。
	 *
	 * @param request リクエスト情報
	 * @see jp.co.future.common.palette.rtfa.parameter.PaletteBaseParameter#setRequest(jp.co.future.common.palette.rtfa.parameter.PaletteBaseRequestParameter)
	 */
	@Override
	public void setRequest(final PaletteBaseRequestParameter request) {
		this.request = (R10040RequestParameter) request;
	}

	/**
	 * リプライ情報を返します。
	 *
	 * @return リプライ情報
	 * @see jp.co.future.common.palette.rtfa.parameter.PaletteBaseParameter#getReply()
	 */
	@SuppressWarnings("unchecked")
	@Override
	public R10040ReplyParameter getReply() {
		return this.reply;
	}

	/**
	 * リプライ情報をセットします。
	 *
	 * @param reply リプライ情報
	 * @see jp.co.future.common.palette.rtfa.parameter.PaletteBaseParameter#setReply(jp.co.future.common.palette.rtfa.parameter.PaletteBaseReplyParameter)
	 */
	@Override
	public void setReply(final PaletteBaseReplyParameter reply) {
		this.reply = (R10040ReplyParameter) reply;
	}
}