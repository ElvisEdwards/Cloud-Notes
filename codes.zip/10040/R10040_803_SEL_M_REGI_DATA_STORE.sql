/*BEGIN*/
/*
 * 処理概要：
 * レジデータ店舗マスタから地区部名の一覧を取得する。
 *
 */
/*END*/
select /* _SQL_IDENTIFIER_ */
	mrds.district_depart_nm	as	label	-- レジデータ店舗マスタ.地区部名
,	mrds.district_depart	as	value	-- レジデータ店舗マスタ.地区部
from
	m_regi_data_store	mrds	-- レジデータ店舗マスタ
where
	mrds.del_flg							=		/*#CLS_FLAG_OFF*/'00'				-- レジデータ店舗マスタ.削除フラグ
and	cast(/*shoriYmd*/'20170101'	as	date)	between	mrds.start_date	and	mrds.end_date	-- 業務日付 BETWEEN レジデータ店舗マスタ.適用開始日 AND レジデータ店舗マスタ.適用終了日
group by
	mrds.district_depart_nm	-- レジデータ店舗マスタ.地区部名
,	mrds.district_depart	-- レジデータ店舗マスタ.地区部
order by
	mrds.district_depart_nm	-- レジデータ店舗マスタ.地区部名
