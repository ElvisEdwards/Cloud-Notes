package jp.co.future.fjy.common.parameter.ord;

import org.msgpack.annotation.MessagePackMessage;

import jp.co.future.fjy.common.parameter.biz.BizBaseWebRequestParameter;

/**
 * 10040；セール発注CSVダウンロード
 *
 * @author 侯慶好
 */
@MessagePackMessage
public class R10040RequestParameter extends BizBaseWebRequestParameter {
	/** セール区分 */
	public String saleTyp;
	/** 画面.セール表示開始日 */
	public String saleDispBegnDate;
	/** 画面.セール表示終了日 */
	public String saleDispFinishDate;
	/** 画面.セール名 */
	public String saleNm;
	/** 画面.業務 */
	public String bizCd;
	/** 画面.地区 */
	public String districtTyp;
	/** 画面.地区サブ */
	public String districtSubNm;
	/** 画面.地区部 */
	public String districtDepartNm;
	/** 画面.SV */
	public String svCd;
	/** 画面.店舗コード */
	public String storeCd;
	/** 画面.店舗名 */
	public String storeNm;
	/** 画面.部門名 */
	public String typValNm;
	/** 部門コード */
	public String departmentCd;
	/** 画面.チャネル */
	public String channel;

	/**
	 * セール区分を取得します
	 *
	 * @return saleTyp セール区分
	 */
	public String getSaleTyp() {
		return this.saleTyp;
	}

	/**
	 * セール区分をセットします
	 *
	 * @param saleTyp セール区分
	 */
	public void setSaleTyp(final String saleTyp) {
		this.saleTyp = saleTyp;
	}

	/**
	 * 画面.セール表示開始日を取得します
	 *
	 * @return saleDispBegnDate 画面.セール表示開始日
	 */
	public String getSaleDispBegnDate() {
		return this.saleDispBegnDate;
	}

	/**
	 * 画面.セール表示開始日をセットします
	 *
	 * @param saleDispBegnDate 画面.セール表示開始日
	 */
	public void setSaleDispBegnDate(final String saleDispBegnDate) {
		this.saleDispBegnDate = saleDispBegnDate;
	}

	/**
	 * 画面.セール表示終了日を取得します
	 *
	 * @return saleDispFinishDate 画面.セール表示終了日
	 */
	public String getSaleDispFinishDate() {
		return this.saleDispFinishDate;
	}

	/**
	 * 画面.セール表示終了日をセットします
	 *
	 * @param saleDispFinishDate 画面.セール表示終了日
	 */
	public void setSaleDispFinishDate(final String saleDispFinishDate) {
		this.saleDispFinishDate = saleDispFinishDate;
	}

	/**
	 * 画面.セール名を取得します
	 *
	 * @return saleNm 画面.セール名
	 */
	public String getSaleNm() {
		return this.saleNm;
	}

	/**
	 * 画面.セール名をセットします
	 *
	 * @param saleNm 画面.セール名
	 */
	public void setSaleNm(final String saleNm) {
		this.saleNm = saleNm;
	}

	/**
	 * 画面.業務を取得します
	 *
	 * @return bizCd 画面.業務
	 */
	public String getBizCd() {
		return this.bizCd;
	}

	/**
	 * 画面.業務をセットします
	 *
	 * @param bizCd 画面.業務
	 */
	public void setBizCd(final String bizCd) {
		this.bizCd = bizCd;
	}

	/**
	 * 画面.地区を取得します
	 *
	 * @return districtTyp 画面.地区
	 */
	public String getDistrictTyp() {
		return this.districtTyp;
	}

	/**
	 * 画面.地区をセットします
	 *
	 * @param districtTyp 画面.地区
	 */
	public void setDistrictTyp(final String districtTyp) {
		this.districtTyp = districtTyp;
	}

	/**
	 * 画面.地区サブを取得します
	 *
	 * @return districtSubNm 画面.地区サブ
	 */
	public String getDistrictSubNm() {
		return this.districtSubNm;
	}

	/**
	 * 画面.地区サブをセットします
	 *
	 * @param districtSubNm 画面.地区サブ
	 */
	public void setDistrictSubNm(final String districtSubNm) {
		this.districtSubNm = districtSubNm;
	}

	/**
	 * 画面.地区部を取得します
	 *
	 * @return districtDepartNm 画面.地区部
	 */
	public String getDistrictDepartNm() {
		return this.districtDepartNm;
	}

	/**
	 * 画面.地区部をセットします
	 *
	 * @param districtDepartNm 画面.地区部
	 */
	public void setDistrictDepartNm(final String districtDepartNm) {
		this.districtDepartNm = districtDepartNm;
	}

	/**
	 * 画面.SVを取得します
	 *
	 * @return svCd 画面.SV
	 */
	public String getSvCd() {
		return this.svCd;
	}

	/**
	 * 画面.SVをセットします
	 *
	 * @param svCd 画面.SV
	 */
	public void setSvCd(final String svCd) {
		this.svCd = svCd;
	}

	/**
	 * 画面.店舗コードを取得します
	 *
	 * @return storeCd 画面.店舗コード
	 */
	public String getStoreCd() {
		return this.storeCd;
	}

	/**
	 * 画面.店舗コードをセットします
	 *
	 * @param storeCd 画面.店舗コード
	 */
	public void setStoreCd(final String storeCd) {
		this.storeCd = storeCd;
	}

	/**
	 * 画面.店舗名を取得します
	 *
	 * @return storeNm 画面.店舗名
	 */
	public String getStoreNm() {
		return this.storeNm;
	}

	/**
	 * 画面.店舗名をセットします
	 *
	 * @param storeNm 画面.店舗名
	 */
	public void setStoreNm(final String storeNm) {
		this.storeNm = storeNm;
	}

	/**
	 * 画面.部門名を取得します
	 *
	 * @return typValNm 画面.部門名
	 */
	public String getTypValNm() {
		return this.typValNm;
	}

	/**
	 * 画面.部門名をセットします
	 *
	 * @param typValNm 画面.部門名
	 */
	public void setTypValNm(final String typValNm) {
		this.typValNm = typValNm;
	}

	/**
	 * 部門コードを取得します
	 *
	 * @return departmentCd 部門コード
	 */
	public String getDepartmentCd() {
		return this.departmentCd;
	}

	/**
	 * 部門コードをセットします
	 *
	 * @param departmentCd 部門コード
	 */
	public void setDepartmentCd(final String departmentCd) {
		this.departmentCd = departmentCd;
	}

	/**
	 * 画面.チャネルを取得します
	 *
	 * @return channel 画面.チャネル
	 */
	public String getChannel() {
		return this.channel;
	}

	/**
	 * 画面.チャネルをセットします
	 *
	 * @param channel 画面.チャネル
	 */
	public void setChannel(final String channel) {
		this.channel = channel;
	}
}