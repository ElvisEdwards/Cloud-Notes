/*BEGIN*/
/*
 * 処理概要：
 * セールマスタからセール情報を取得する。
 *
 */
/*END*/
select /* _SQL_IDENTIFIER_ */
	msll.sell_id																					as	sell_id				-- セールID
,	msll.sell_nm	||	'('	||	msll.disp_begn_date	||	' ～ '	||	msll.disp_finish_date	||	')'	as	label				-- 表示セール名 （ セール名 + "(" + セール表示開始日 + " ～ " +　セール表示終了日 + ")" ）
,	msll.sell_typ																					as	value			-- セール区分
,	msll.disp_begn_date																				as	disp_begn_date		-- 表示開始日
,	msll.disp_finish_date																			as	disp_finish_date	-- 表示終了日
from
	m_sell	msll	-- セールマスタ
where
	msll.del_flg							=		/*#CLS_FLAG_OFF*/'00'								-- セールマスタ.削除フラグ
and	cast(/*shoriYmd*/'20170101'	as	date)	between	msll.disp_begn_date	and	msll.last_ref_possible_date	-- 業務日付 BETWEEN 表示開始日 AND 最終参照可能日
order by
	msll.disp_begn_date		-- 表示開始日
,	msll.disp_finish_date	-- 表示終了日
