package jp.co.future.fjy.common.parameter.por;

import org.msgpack.annotation.MessagePackMessage;

import jp.co.future.fjy.common.parameter.biz.BizBaseAsyncResultParameter;

/**
 * 10293:発注要求データ洗替え
 *
 * @author Future 侯慶好
 */
@MessagePackMessage
public class R10293ResultParameter extends BizBaseAsyncResultParameter {

}
