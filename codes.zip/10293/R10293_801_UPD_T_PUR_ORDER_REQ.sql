/*BEGIN*/
/*
 * 処理概要：
 * 最新のマスタデータを取得して、発注要求トランを更新する。
 *
 */
/*END*/
update /* _SQL_IDENTIFIER_ */
	t_pur_order_req	tpor	-- 発注要求トラン
set
	pur_order_req_closing_id	=mspro.pur_order_closing_id																		-- 発注要求締めID
,	pur_order_req_closing_date	=tpor.pur_order_req_closing_date-	make_interval(days	=>	cast(mspro.sply_lt	as	integer))	-- 発注要求締め日
,	store_cd					=mspro.store_cd																					-- 店舗コード
,	department_cd				=mspro.department_cd																				-- 部門コード
,	store_nm					=mspro.store_nm																					-- 店舗名
,	ship_to_typ					=mspro.ship_to_typ																				-- 出荷先区分
,	district_typ				=mspro.district_typ																				-- 地区区分
,	sub_district_typ			=mspro.sub_district_typ																			-- サブ地区区分
,	district_sub_nm				=mspro.district_sub_nm																			-- 地区サブ名
,	district_depart_nm			=mspro.district_depart_nm																		-- 地区部名
,	sv_cd						=mspro.sv_cd																						-- svコード
,	product_cd					=mspro.product_cd																				-- 製品コード
,	product_nm					=mspro.product_nm																				-- 製品名
,	biz_cd						=mspro.biz_cd																					-- 業務コード
,	part_no						=mspro.part_no																					-- 品番
,	regi_large_class_id			=mspro.regi_large_class_id																		-- レジ大分類ID
,	regi_large_class_cd			=mspro.regi_large_class_cd																		-- レジ大分類コード
,	regi_large_class_nm			=mspro.regi_large_class_nm																		-- レジ大分類名
,	regi_middle_class_id		=mspro.regi_middle_class_id																		-- レジ中分類ID
,	regi_middle_class_cd		=mspro.regi_middle_class_cd																		-- レジ中分類コード
,	regi_middle_class_nm		=mspro.regi_middle_class_nm																		-- レジ中分類名
,	regi_small_class_id			=mspro.regi_small_class_id																		-- レジ小分類ID
,	regi_small_class_cd			=mspro.regi_small_class_cd																		-- レジ小分類コード
,	regi_small_class_nm			=mspro.regi_small_class_nm																		-- レジ小分類名
,	piece_class_id				=mspro.piece_class_id																			-- 単品分類ID
,	piece_class_cd				=mspro.piece_class_cd																			-- 単品分類コード
,	piece_class_nm				=mspro.piece_class_nm																			-- 単品分類名
,	deliv_lt					=mspro.sply_lt																					-- 納品LT
,	qty							=mspro.qty																						-- 入数
,	pur_order_pur_unit_cost		=mspro.pur_order_pur_unit_cost																	-- 発注仕入原単価
,	pur_order_pur_cost_amt		=mspro.pur_order_pur_unit_cost*tpor.pur_order_unit_req_qty										-- 発注仕入原価金額
,	sales_unit_prc				=	(
		case
			when
				mbsiss.sell_unit_prc	is	null
			then
				mspro.sell_unit_prc
			else
				mbsiss.sell_unit_prc
		end
	)																																-- 販売売単価
,	sell_prc_amt				=	(
		case
			when
				mbsiss.sell_unit_prc	is	null
			then
				mspro.sell_unit_prc*mspro.qty*tpor.pur_order_unit_req_qty
			else
				mbsiss.sell_unit_prc*mspro.qty*tpor.pur_order_unit_req_qty
		end
	)																																-- 売価金額
/*IF purOrderReqReversalSourceTyp != #CLS_PUR_ORDER_REQ_REVERSAL_SOURCE_TYP_STORE_CLOSING*/
,	pur_order_req_send_cond_typ	=	(
		case
			(
					tpor.store_cd			=	mspro.store_cd
				and	tpor.department_cd		=	mspro.department_cd
				and	tpor.biz_cd				=	mspro.biz_cd
				and	tpor.part_no			=	mspro.part_no
				and	tpor.district_typ		=	mspro.district_typ
				and	tpor.product_cd			=	mspro.product_cd
				and	tpor.sub_district_typ	=	mspro.sub_district_typ
				)
			when
				true
			then
				tpor.pur_order_req_send_cond_typ
			else
				/*#CLS_SEND_COND_TYP_NOT_SEND*/'10'
		end
	)																																-- 発注要求送信状態区分
/*END*/
,	last_upd_user_id			=/*userId*/1																						-- 最終更新ユーザーID
,	last_upd_user_acct_cd		=/*userAcctCd*/'1'																				-- 最終更新ユーザーアカウントコード
,	last_upd_user_nm			=/*userNm*/'1'																					-- 最終更新ユーザー名
,	last_upd_user_nm_kana		=/*userNmKana*/'1'																				-- 最終更新ユーザー名カナ
,	last_upd_datetime			=/*balanceDatetime*/'20180101'																	-- 最終更新日時
from
	m_store_product	mspro	-- 店別製品マスタ
left outer join
	m_by_store_item_separate_set	mbsiss	-- 店別商品個別設定マスタ
on
	mbsiss.item_id	=	mspro.item_id	-- 店別商品個別設定マスタ.商品ID = 店別製品マスタ.商品ID
and	mbsiss.org_id	=	mspro.org_id	-- 店別商品個別設定マスタ.組織ID = 店別製品マスタ.組織ID
where
	tpor.del_flg					=		/*#CLS_FLAG_OFF*/'00'																																									-- 発注要求トラン.削除フラグ
and	tpor.in_deliv_sched_date		between	cast(/*shoriYmd*/'20180101'	as	date)	and	cast(/*shoriYmd*/'20180101'	as	date)	+	/*#CLS_GPR_MAX_FUTURE_NUMBER_OF_DAY_IN_DELIV_SCHED_DATE_MAX_FUTURE_NUMBER_OF_DAY*/'20180102'	-- 発注要求トラン.入荷予定日 between 業務日付 and 業務日付 + [汎用パラメータ.最大未来日数.入荷予定日最大未来日数]
/*IF purOrderReqReversalSourceTyp eq #CLS_PUR_ORDER_REQ_REVERSAL_SOURCE_TYP_STORE_CLOSING*/
and	tpor.pur_order_req_closing_id	=		/*purOrderClosingId*/1																																									-- 発注要求トラン.発注要求締めID = 引数.発注締めID
and	tpor.pur_order_req_closing_date	=		cast(/*shoriYmd*/'20180101'	as	date)	-- 発注要求トラン.発注要求締め日 = 業務日付
/*ELSE*/
and	tpor.pur_order_req_closing_date	>		cast(/*shoriYmd*/'20180101'	as	date)	-- 発注要求トラン.発注要求締め日　>　業務日付
/*END*/
and	mspro.store_id					=		tpor.store_id																																											-- 店別製品マスタ.店舗ID =　発注要求トラン.店舗ID
and	mspro.product_id				=		tpor.product_id																																											-- 店別製品マスタ.製品ID = 発注要求トラン.製品ID
and	tpor.pur_order_req_closing_date	between	mspro.start_date	and	mspro.end_date																																					-- 発注要求トラン.発注要求締め日 between 店別製品マスタ.適用開始日 and 店別製品マスタ.適用終了日
