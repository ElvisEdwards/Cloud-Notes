package jp.co.future.fjy.common.parameter.por;

import org.hibernate.validator.constraints.NotBlank;
import org.msgpack.annotation.MessagePackMessage;

import jp.co.future.common.appcore.constraints.NarrowNumeric;
import jp.co.future.fjy.common.parameter.biz.BizBaseAsyncRequestParameter;

/**
 * 10293:発注要求データ洗替え
 *
 * @author Future 侯慶好
 */
@MessagePackMessage
public class R10293RequestParameter extends BizBaseAsyncRequestParameter {
	/** 発注締めID */
	@NarrowNumeric
	public String purOrderClosingId;

	/** 発注要求洗替発生区分 */
	@NotBlank
	@NarrowNumeric
	public String purOrderReqReversalSourceTyp;

	/**
	 * 発注締めIDを取得します
	 *
	 * @return purOrderClosingId 発注締めID
	 */
	public String getPurOrderClosingId() {
		return this.purOrderClosingId;
	}

	/**
	 * 発注締めIDをセットします
	 *
	 * @param purOrderClosingId 発注締めID
	 */
	public void setPurOrderClosingId(final String purOrderClosingId) {
		this.purOrderClosingId = purOrderClosingId;
	}

	/**
	 * 発注要求洗替発生区分を取得します
	 *
	 * @return purOrderReqReversalSourceTyp 発注要求洗替発生区分
	 */
	public String getPurOrderReqReversalSourceTyp() {
		return this.purOrderReqReversalSourceTyp;
	}

	/**
	 * 発注要求洗替発生区分をセットします
	 *
	 * @param purOrderReqReversalSourceTyp 発注要求洗替発生区分
	 */
	public void setPurOrderReqReversalSourceTyp(final String purOrderReqReversalSourceTyp) {
		this.purOrderReqReversalSourceTyp = purOrderReqReversalSourceTyp;
	}

}
