package jp.co.future.fjy.bl.controller.por;

import org.springframework.stereotype.Controller;

import jp.co.future.common.appcore.utils.DateUtils;
import jp.co.future.common.appcore.utils.NumberUtils;
import jp.co.future.common.appcore.utils.UtilsConsts.DateScope.Formats;
import jp.co.future.common.palette.commands.SqlExecuteCommand;
import jp.co.future.common.palette.commands.exceptions.CommandLogicException;
import jp.co.future.fjy.bl.controller.biz.BizBaseAsyncController;
import jp.co.future.fjy.common.constants.type.BizTypeConsts;
import jp.co.future.fjy.common.parameter.por.R10293Parameter;
import jp.co.future.fjy.common.parameter.por.R10293RequestParameter;

/**
 * 10293:発注要求データ洗替え
 *
 * @author Future 侯慶好
 */
@Controller
public class R10293Controller extends BizBaseAsyncController<R10293Parameter> {

	/**
	 * 発注要求データ洗替え
	 */
	@Override
	protected void doExecuteInternal() throws CommandLogicException {

		// パラメータ取得
		R10293RequestParameter request = getParameter().getRequest();

		//requestのフィールド「発注要求洗替発生区分」に対して「区分種別.発注要求洗替発生区分」に含まれているかを確認
		this.validateTypeParameter(request.getPurOrderReqReversalSourceTyp(),
				BizTypeConsts.PUR_ORDER_REQ_REVERSAL_SOURCE_TYP);
		if (this.hasError()) {
			//Errorがある場合処理を止める。
			return;
		}

		// SqlExecuteCommandを生成
		SqlExecuteCommand command1 = this.createSqlExecuteCommand("por/R10293_801_UPD_T_PUR_ORDER_REQ");
		// 発注締めID
		command1.addParam("purOrderClosingId", request.getPurOrderClosingId());
		// 発注要求洗替発生区分
		command1.addParam("purOrderReqReversalSourceTyp", request.getPurOrderReqReversalSourceTyp());
		// システム.ユーザーID
		command1.addParam("userId", NumberUtils.toInt(request.getUserId()));
		// システム.ユーザーアカウントコード
		command1.addParam("userAcctCd", request.getUserAcctCd());
		// システム.ユーザー名称
		command1.addParam("userNm", request.getFullName());
		// システム.ユーザー名称カナ
		command1.addParam("userNmKana", request.getFullNameKana());
		// システム.システム日時
		command1.addParam("balanceDatetime", DateUtils.parse(getNow(), Formats.YMD_HMS_SSS));
		// SQLの実行
		executeCommand(command1);

		// [区分値.発注要求洗替発生区分.店舗締]以外
		if (!BizTypeConsts.PUR_ORDER_REQ_REVERSAL_SOURCE_TYP_STORE_CLOSING
				.equals(request.getPurOrderReqReversalSourceTyp())) {
			// SqlExecuteCommandを生成
			SqlExecuteCommand command2 = this.createSqlExecuteCommand("por/R10293_802_UPD_T_SELL_PUR_ORDER_REQ");
			// システム.ユーザーID
			command2.addParam("userId", NumberUtils.toInt(request.getUserId()));
			// システム.ユーザーアカウントコード
			command2.addParam("userAcctCd", request.getUserAcctCd());
			// システム.ユーザー名称
			command2.addParam("userNm", request.getFullName());
			// システム.ユーザー名称カナ
			command2.addParam("userNmKana", request.getFullNameKana());
			// システム.システム日時
			command2.addParam("balanceDatetime", DateUtils.parse(getNow(), Formats.YMD_HMS_SSS));
			// SQLの実行
			executeCommand(command2);
		}
	}
}
