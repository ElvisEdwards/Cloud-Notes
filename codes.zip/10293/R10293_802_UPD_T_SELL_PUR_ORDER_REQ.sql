/*BEGIN*/
/*
 * 処理概要：
 * 最新のマスタデータを取得して、セール発注要求トランを更新する。
 *
 */
/*END*/
update /* _SQL_IDENTIFIER_ */
	t_sell_pur_order_req	tspor	-- セール発注要求トラン
set
	pur_order_req_closing_id	=msspop.pur_order_closing_id																		-- 発注要求締めID
,	pur_order_req_closing_date	=tspor.pur_order_req_closing_date-	make_interval(days	=>	cast(msspop.sply_lt	as	integer))	-- 発注要求締め日
,	store_cd					=msspop.store_cd																					-- 店舗コード
,	department_cd				=msspop.department_cd																			-- 部門コード
,	store_nm					=msspop.store_nm																					-- 店舗名
,	ship_to_typ					=msspop.ship_to_typ																				-- 出荷先区分
,	district_typ				=msspop.district_typ																				-- 地区区分
,	sub_district_typ			=msspop.sub_district_typ																			-- サブ地区区分
,	district_sub_nm				=msspop.district_sub_nm																			-- 地区サブ名
,	district_depart_nm			=msspop.district_depart_nm																		-- 地区部名
,	sv_cd						=msspop.sv_cd																					-- svコード
,	product_cd					=msspop.product_cd																				-- 製品コード
,	product_nm					=msspop.product_nm																				-- 製品名
,	biz_cd						=msspop.biz_cd																					-- 業務コード
,	part_no						=msspop.part_no																					-- 品番
,	regi_large_class_id			=msspop.regi_large_class_id																		-- レジ大分類ID
,	regi_large_class_cd			=msspop.regi_large_class_cd																		-- レジ大分類コード
,	regi_large_class_nm			=msspop.regi_large_class_nm																		-- レジ大分類名
,	regi_middle_class_id		=msspop.regi_middle_class_id																		-- レジ中分類ID
,	regi_middle_class_cd		=msspop.regi_middle_class_cd																		-- レジ中分類コード
,	regi_middle_class_nm		=msspop.regi_middle_class_nm																		-- レジ中分類名
,	regi_small_class_id			=msspop.regi_small_class_id																		-- レジ小分類ID
,	regi_small_class_cd			=msspop.regi_small_class_cd																		-- レジ小分類コード
,	regi_small_class_nm			=msspop.regi_small_class_nm																		-- レジ小分類名
,	piece_class_id				=msspop.piece_class_id																			-- 単品分類ID
,	piece_class_cd				=msspop.piece_class_cd																			-- 単品分類コード
,	piece_class_nm				=msspop.piece_class_nm																			-- 単品分類名
,	deliv_lt					=msspop.sply_lt																					-- 納品LT
,	qty							=msspop.qty																						-- 入数
,	pur_order_pur_unit_cost		=msspop.pur_order_pur_unit_cost																	-- 発注仕入原単価
,	pur_order_pur_cost_amt		=msspop.pur_order_pur_unit_cost*tspor.pur_order_unit_req_qty										-- 発注仕入原価金額
,	sales_unit_prc				=	(
		case
			when
				mbsiss.sell_unit_prc	is	null
			then
				msspop.sell_unit_prc
			else
				mbsiss.sell_unit_prc
		end
	)																																-- 販売売単価
,	sell_prc_amt				=	(
		case
			when
				mbsiss.sell_unit_prc	is	null
			then
				msspop.sell_unit_prc*msspop.qty*tspor.pur_order_unit_req_qty
			else
				mbsiss.sell_unit_prc*msspop.qty*tspor.pur_order_unit_req_qty
		end
	)																																-- 売価金額
,	pur_order_req_send_cond_typ	=	(
		case
			when
				tspor.sale_typ	=	/*#CLS_SALE_TYP_LONG_LT_NORMAL_PUR_ORDER*/'99'
			then
				(
				case
					tspor.store_cd	=	msspop.store_cd
					and	tspor.department_cd	=	msspop.department_cd
					and	tspor.biz_cd	=	msspop.biz_cd
					and	tspor.part_no	=	msspop.part_no
					and	tspor.district_typ	=	msspop.district_typ
					and	tspor.product_cd	=	msspop.product_cd
					and	tspor.sub_district_typ	=	msspop.sub_district_typ
					when
						true
					then
						tspor.pur_order_req_send_cond_typ
					else
						/*#CLS_SEND_COND_TYP_NOT_SEND*/'10'
				end
			)
			else
				tspor.pur_order_req_send_cond_typ
		end
	)																																-- 発注要求送信状態区分
,	last_upd_user_id			=/*userId*/1																						-- 最終更新ユーザーID
,	last_upd_user_acct_cd		=/*userAcctCd*/'1'																				-- 最終更新ユーザーアカウントコード
,	last_upd_user_nm			=/*userNm*/'1'																					-- 最終更新ユーザー名
,	last_upd_user_nm_kana		=/*userNmKana*/'1'																				-- 最終更新ユーザー名カナ
,	last_upd_datetime			=/*balanceDatetime*/'20180101'																	-- 最終更新日時
from
	m_store_sale_pur_order_product	msspop	-- 店別セール発注製品マスタ
left outer join
	m_by_store_item_separate_set	mbsiss	-- 店別商品個別設定マスタ
on
	mbsiss.item_id	=	msspop.item_id	-- 店別商品個別設定マスタ.商品ID = 店別製品マスタ.商品ID
and	mbsiss.org_id	=	msspop.org_id	-- 店別商品個別設定マスタ.組織ID = 店別製品マスタ.組織ID
where
	1									=		1
and	tspor.in_deliv_sched_date			between	cast(/*shoriYmd*/'20180101'	as	date)	and	cast(/*shoriYmd*/'20180101'	as	date)+/*#CLS_GPR_MAX_FUTURE_NUMBER_OF_DAY_IN_DELIV_SCHED_DATE_MAX_FUTURE_NUMBER_OF_DAY*/'20180102'	-- セール発注要求トラン.入荷予定日 between 業務日付 and 業務日付 + [汎用パラメータ.最大未来日数.入荷予定日最大未来日数]
and	tspor.pur_order_req_closing_date	>=		cast(/*shoriYmd*/'20180101'	as	date)	-- セール発注要求トラン.発注要求締め日　>=　業務日付
and	msspop.store_id						=		tspor.store_id																																									-- 店別セール発注製品マスタ.店舗ID =　セール発注要求トラン.店舗ID
and	msspop.sale_typ						=		tspor.sale_typ																																									-- 店別セール発注製品マスタ.セール区分 =　セール発注要求トラン.セール区分
and	msspop.disp_begn_date				=		tspor.sale_disp_begn_date																																						-- 店別セール発注製品マスタ.表示開始日 =　セール発注要求トラン.表示開始日
and	msspop.disp_finish_date				=		tspor.sale_disp_finish_date																																						-- 店別セール発注製品マスタ.表示終了日 =　セール発注要求トラン.表示終了日
and	msspop.product_id					=		tspor.product_id																																								-- 店別セール発注製品マスタ.製品ID = セール発注要求トラン.製品ID
and	msspop.forwarding_begn_date			=		tspor.forwarding_begn_date																																						-- 店別セール発注製品マスタ.廻送日付開始 = セール発注要求トラン.廻送日付開始
