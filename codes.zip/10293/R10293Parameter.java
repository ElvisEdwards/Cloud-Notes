package jp.co.future.fjy.common.parameter.por;

import org.msgpack.annotation.MessagePackMessage;

import jp.co.future.common.palette.rtfa.parameter.PaletteBaseReplyParameter;
import jp.co.future.common.palette.rtfa.parameter.PaletteBaseRequestParameter;
import jp.co.future.fjy.common.parameter.biz.BizBaseAsyncParameter;
import jp.co.future.fjy.common.parameter.biz.BizBaseAsyncResultParameter;

/**
 * 10293:発注要求データ洗替え
 *
 * @author Future 侯慶好
 */
@MessagePackMessage
public class R10293Parameter extends BizBaseAsyncParameter {

	/**
	 * リクエスト情報。
	 */
	public R10293RequestParameter request = null;

	/**
	 * リプライ情報。
	 */
	public R10293ReplyParameter reply = null;

	/**
	 * リザルト情報.
	 */
	public R10293ResultParameter result = null;

	// ----------------- アクセサ ---------------------------
	/**
	 * リクエスト情報を返します。
	 *
	 * @return リクエスト情報
	 * @see jp.co.future.common.palette.rtfa.core.parameter.PaletteBaseParameter#getRequest()
	 */
	@SuppressWarnings("unchecked")
	@Override
	public R10293RequestParameter getRequest() {
		return this.request;
	}

	/**
	 * リクエスト情報をセットします。
	 *
	 * @param request リクエスト情報
	 * @see jp.co.future.common.palette.rtfa.core.parameter.PaletteBaseParameter#setRequest(jp.co.future.common.palette.rtfa.core.parameter.PaletteBaseRequestParameter)
	 */
	@Override
	public void setRequest(final PaletteBaseRequestParameter request) {
		this.request = (R10293RequestParameter) request;
	}

	/**
	 * リプライ情報を返します。
	 *
	 * @return リプライ情報
	 * @see jp.co.future.common.palette.rtfa.core.parameter.PaletteBaseParameter#getReply()
	 */
	@SuppressWarnings("unchecked")
	@Override
	public R10293ReplyParameter getReply() {
		return this.reply;
	}

	/**
	 * リプライ情報をセットします。
	 *
	 * @param reply リプライ情報
	 * @see jp.co.future.common.palette.rtfa.core.parameter.PaletteBaseParameter#setReply(jp.co.future.common.palette.rtfa.core.parameter.PaletteBaseReplyParameter)
	 */
	@Override
	public void setReply(final PaletteBaseReplyParameter reply) {
		this.reply = (R10293ReplyParameter) reply;
	}

	/**
	 * リザルト情報をセットします
	 *
	 * @param result リザルト情報
	 * @see jp.co.future.skyretail.std.common.parameter.biz.BizBaseJobParameter#setResult(jp.co.future.skyretail.std.common.parameter.biz.BizBaseAsyncResultParameter)
	 */
	@Override
	public void setResult(final BizBaseAsyncResultParameter result) {
		this.result = (R10293ResultParameter) result;
	}

	/**
	 * リザルト情報を返します。
	 *
	 * @param リザルト情報
	 * @see jp.co.future.skyretail.std.common.parameter.biz.BizBaseJobParameter#getResult()
	 */
	@SuppressWarnings("unchecked")
	@Override
	public R10293ResultParameter getResult() {
		return this.result;
	}
}