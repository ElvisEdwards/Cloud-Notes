/*BEGIN*/
/*
 * 処理概要：
 * 引数.送信状態更新モードが[区分値.送信状態区分.送信中]の場合、
 * POS店舗精算トラン.送信状態区分が[区分値.送信状態区分.送信中]のデータを対象にPOS店舗精算トラン.送信状態区分を[区分値.送信状態区分.送信済]に更新する。
 *
 */
/*END*/
update /* _SQL_IDENTIFIER_ */
	t_pos_store_payoff	tpsp	-- POS店舗精算トラン
set
	send_cond_typ			=	/*#CLS_SEND_COND_TYP_SENT*/'30'											-- 送信状態区分
,	upd_pgm_cd				=	/*updPgmCd*/'cmtpx01050'												-- 更新プログラムコード
,	upd_date				=	/*updDate*/'99991231000000'												-- 更新システム日時
,	upd_user_acct_cd		=	/*updUserAcctCd*/'000001'												-- 更新ユーザアカウントコード
,	upd_terminal_ip_addr	=	/*updTerminalIpAddr*/''													-- 更新端末IPアドレス
,	upd_trn_id				=	/*updTrnId*/''															-- 更新トランザクションID
,	lock_no					=	mod(tpsp.lock_no, /*#CLS_POSTGRESQL_INTEGER_MAX*/2147483647)	+	1	-- ロック番号
where
	tpsp.del_flg		=	/*#CLS_FLAG_OFF*/'00'				-- 削除フラグ
and	tpsp.send_cond_typ	=	/*#CLS_SEND_COND_TYP_SENDING*/'20'	-- 送信状態区分
